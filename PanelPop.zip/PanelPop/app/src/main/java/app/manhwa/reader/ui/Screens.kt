package app.manhwa.reader.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import app.manhwa.reader.R
import app.manhwa.reader.data.Manhwa
import app.manhwa.reader.translate.PageTranslator
import app.manhwa.reader.translate.TextBox
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.size.Size
import kotlin.math.sqrt

// ───────────────────────── Estructura general ─────────────────────────

@Composable
fun App(vm: AppViewModel) {
    BackHandler(enabled = vm.stack.isNotEmpty()) { vm.back() }
    val s = vm.screen
    val top = s is Screen.Library || s is Screen.Updates || s is Screen.History ||
        s is Screen.Browse || s is Screen.More
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (top) NavigationBar {
                NavigationBarItem(s is Screen.Library, { vm.tab(Screen.Library) }, { Text("📚") }, label = { Text("Biblioteca", fontSize = 11.sp, maxLines = 1) })
                NavigationBarItem(s is Screen.Updates, { vm.tab(Screen.Updates) }, { Text("🔔") }, label = { Text("Novedades", fontSize = 11.sp, maxLines = 1) })
                NavigationBarItem(s is Screen.History, { vm.tab(Screen.History) }, { Text("🕘") }, label = { Text("Historial", fontSize = 11.sp, maxLines = 1) })
                NavigationBarItem(s is Screen.Browse, { vm.tab(Screen.Browse) }, { Text("🧭") }, label = { Text("Explorar", fontSize = 11.sp, maxLines = 1) })
                NavigationBarItem(s is Screen.More, { vm.tab(Screen.More) }, { Text("⋯") }, label = { Text("Más", fontSize = 11.sp, maxLines = 1) })
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (s) {
                Screen.Library -> LibraryScreen(vm)
                Screen.Updates -> UpdatesScreen(vm)
                Screen.History -> HistoryScreen(vm)
                Screen.Browse -> BrowseScreen(vm)
                Screen.More -> MoreScreen(vm)
                Screen.Sources -> SourcesScreen(vm)
                is Screen.Detail -> DetailScreen(vm, s.m)
                is Screen.Reader -> ReaderScreen(vm, s.m, s.index)
            }
        }
    }
}

/** Logo de Panel Pop: globo de cómic con explosión "!" sobre degradado morado-rosa. */
@Composable
fun PanelPopLogo(size: Dp = 72.dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.22f))
            .background(Brush.linearGradient(listOf(Color(0xFF7B2FF7), Color(0xFFFF4F8B))))
    ) {
        Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.fillMaxSize())
    }
}

// ───────────────────────── Cuadrícula de portadas ─────────────────────────

@Composable
fun CoverCard(m: Manhwa, badge: Int, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.68f)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(m.cover, m.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                .padding(8.dp, 26.dp, 8.dp, 8.dp)
        ) {
            Text(
                m.title, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (badge > 0) {
            Text(
                "$badge",
                Modifier
                    .padding(6.dp)
                    .align(Alignment.TopStart)
                    .background(MaterialTheme.colorScheme.secondary, RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp,
            )
        }
    }
}

@Composable
fun MangaGrid(
    items: List<Manhwa>,
    onClick: (Manhwa) -> Unit,
    badge: (Manhwa) -> Int = { 0 },
    footer: (@Composable () -> Unit)? = null,
) {
    LazyVerticalGrid(
        GridCells.Fixed(3),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(items, key = { it.url }) { m -> CoverCard(m, badge(m)) { onClick(m) } }
        footer?.let { f -> item(span = { GridItemSpan(maxLineSpan) }) { f() } }
    }
}

// ───────────────────────── Biblioteca ─────────────────────────

@Composable
fun LibraryScreen(vm: AppViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    val list = vm.library.filter {
        (query.isBlank() || it.title.contains(query, ignoreCase = true)) && (tab == 0 || vm.unread(it) > 0)
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (searching) {
                OutlinedTextField(
                    query, { query = it }, Modifier.weight(1f),
                    placeholder = { Text("Buscar en la biblioteca") }, singleLine = true,
                )
            } else {
                Text("Biblioteca", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall)
            }
            TextButton({ searching = !searching; if (!searching) query = "" }) { Text(if (searching) "✕" else "🔍") }
        }
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Todos") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Sin leer") })
        }
        if (list.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(
                    if (vm.library.isEmpty()) "Tu biblioteca está vacía.\nAñade una fuente en «Más» y explora series."
                    else "No hay resultados",
                    textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp),
                )
            }
        } else {
            MangaGrid(list, { vm.openDetail(it) }, badge = { vm.unread(it) })
        }
    }
}

// ───────────────────────── Novedades ─────────────────────────

@Composable
fun UpdatesScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("Novedades", Modifier.weight(1f), style = MaterialTheme.typography.headlineSmall)
            Button({ vm.checkUpdates() }, enabled = !vm.updating && vm.library.isNotEmpty()) {
                Text(if (vm.updating) "Buscando…" else "Buscar")
            }
        }
        if (vm.updating) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.updates.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(
                    "Aquí aparecerán los capítulos nuevos de tu biblioteca.\nToca «Buscar» para comprobar.",
                    textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp),
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.updates) { u ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.openDetail(u.m) }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AsyncImage(
                            u.m.cover, null,
                            Modifier.size(width = 48.dp, height = 68.dp).clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop,
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(u.m.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                u.chapter.title.ifBlank { "Capítulo nuevo" },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Historial ─────────────────────────

@Composable
fun HistoryScreen(vm: AppViewModel) {
    val fmt = remember { java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale.getDefault()) }
    Column(Modifier.fillMaxSize()) {
        Text(
            "Historial", Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp),
            style = MaterialTheme.typography.headlineSmall,
        )
        if (vm.history.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("Aún no has leído nada.", textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp))
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(vm.history) { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.openDetail(h.m) }.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AsyncImage(
                            h.m.cover, null,
                            Modifier.size(width = 48.dp, height = 68.dp).clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop,
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.m.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                h.chapterTitle + " · " + fmt.format(java.util.Date(h.time)),
                                style = MaterialTheme.typography.bodySmall, color = Color.Gray,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Explorar ─────────────────────────

@Composable
fun BrowseScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "Explorar", Modifier.padding(start = 16.dp, top = 12.dp),
            style = MaterialTheme.typography.headlineSmall,
        )
        if (vm.sources.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(
                    "No hay fuentes instaladas.\nVe a «Más > Fuentes» para añadir un repositorio o una web.",
                    textAlign = TextAlign.Center, modifier = Modifier.padding(24.dp),
                )
            }
            return@Column
        }
        LazyRow(contentPadding = PaddingValues(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.sources) { s ->
                FilterChip(vm.current?.id == s.id, { vm.selectSource(s) }, { Text(s.name) })
            }
        }
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
        if (vm.current != null) {
            MangaGrid(vm.items, { vm.openDetail(it) }) {
                Box(Modifier.fillMaxWidth().padding(8.dp), Alignment.Center) {
                    if (vm.loading) CircularProgressIndicator() else Button({ vm.loadMore() }) { Text("Cargar más") }
                }
            }
        }
    }
}

// ───────────────────────── Más ─────────────────────────

@Composable
fun MoreScreen(vm: AppViewModel) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                PanelPopLogo(64.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Panel Pop", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Lee y traduce tus manhwas", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Traducir automáticamente al leer", Modifier.weight(1f))
                Switch(vm.translateOn, { vm.toggleTranslate() })
            }
        }
        item {
            Text("Idioma de traducción (destino)", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("es" to "Español", "en" to "English", "pt" to "Português", "fr" to "Français")) { (c, n) ->
                    FilterChip(vm.targetLang == c, { vm.setTarget(c) }, { Text(n) })
                }
            }
        }
        item {
            Button({ vm.go(Screen.Sources) }, Modifier.fillMaxWidth()) {
                Text("🌐  Fuentes y repositorios (${vm.sources.size})")
            }
        }
        item {
            OutlinedButton({ vm.clearHistory() }, Modifier.fillMaxWidth()) { Text("Borrar historial") }
        }
    }
}

// ───────────────────────── Fuentes ─────────────────────────

@Composable
fun SourcesScreen(vm: AppViewModel) {
    var repoUrl by remember { mutableStateOf("") }
    var webUrl by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.back() }) { Icon(Icons.Default.ArrowBack, "Atrás") }
                Text("Fuentes", style = MaterialTheme.typography.titleLarge)
            }
        }
        item {
            Text("Añadir repositorio", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(
                repoUrl, { repoUrl = it }, Modifier.fillMaxWidth(),
                label = { Text("URL del repositorio (JSON)") }, singleLine = true,
            )
            Button({ vm.addRepo(repoUrl) }, enabled = !vm.busy && repoUrl.isNotBlank()) { Text("Añadir repositorio") }
        }
        item {
            Text("Añadir una web (autodetección)", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(
                webUrl, { webUrl = it }, Modifier.fillMaxWidth(),
                label = { Text("URL del listado de series") }, singleLine = true,
            )
            Button({ vm.detect(webUrl) }, enabled = !vm.busy && webUrl.isNotBlank()) { Text("Detectar") }
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        vm.detected?.let { r ->
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Detectado: ${r.kind} · ${r.sample.size} series", style = MaterialTheme.typography.titleSmall)
                        Text(r.source.name, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        r.sample.take(5).forEach { Text("• ${it.title}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        Spacer(Modifier.height(8.dp))
                        Button({ vm.saveDetected() }) { Text("Guardar fuente") }
                    }
                }
            }
        }
        item { Text("Fuentes instaladas (${vm.sources.size})", style = MaterialTheme.typography.titleSmall) }
        items(vm.sources) { s ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(s.baseUrl, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
                TextButton({ vm.removeSource(s) }) { Text("Quitar") }
            }
        }
    }
}

// ───────────────────────── Detalle ─────────────────────────

@Composable
fun DetailScreen(vm: AppViewModel, m: Manhwa) {
    val inLib = vm.library.any { it.url == m.url }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.padding(12.dp)) {
                AsyncImage(
                    m.cover, null,
                    Modifier.width(100.dp).aspectRatio(0.68f).clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop,
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(m.title, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Button({ vm.toggleLibrary(m) }) { Text(if (inLib) "Quitar de biblioteca" else "Añadir a biblioteca") }
                }
            }
        }
        if (vm.chLoading) item {
            Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator() }
        }
        vm.error?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) } }
        itemsIndexed(vm.chapters) { i, ch ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.go(Screen.Reader(m, i)) }.padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    ch.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = if (ch.url in vm.read) Color.Gray else Color.Unspecified,
                )
                if (ch.date.isNotBlank()) Text(ch.date, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        }
    }
}

// ───────────────────────── Lector ─────────────────────────

@Composable
fun ReaderScreen(vm: AppViewModel, m: Manhwa, index: Int) {
    val ch = vm.chapters.getOrNull(index)
    if (ch == null) {
        Text("Capítulo no disponible", Modifier.padding(16.dp))
        return
    }
    val src = vm.sourceOf(m.sourceId)?.lang ?: "ko"
    LaunchedEffect(ch.url) { vm.loadPages(m, ch) }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.back() }) { Icon(Icons.Default.ArrowBack, "Atrás") }
            Text(ch.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
            FilterChip(
                vm.translateOn, { vm.toggleTranslate() },
                { Text(if (vm.translateOn) "🌐 Traducción: ON" else "🌐 Traducción: OFF") },
            )
            Spacer(Modifier.width(8.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            key(ch.url) {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(vm.pages) { url -> PageView(url, vm.translateOn, src, vm.targetLang) }
                }
            }
            if (vm.pagesLoading) CircularProgressIndicator(Modifier.align(Alignment.Center))
            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.align(Alignment.Center).padding(16.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ vm.replace(Screen.Reader(m, index + 1)) }, enabled = index + 1 < vm.chapters.size) { Text("← Anterior") }
            TextButton({ vm.replace(Screen.Reader(m, index - 1)) }, enabled = index > 0) { Text("Siguiente →") }
        }
    }
}

@Composable
fun PageView(url: String, translate: Boolean, src: String, dst: String) {
    val ctx = LocalContext.current
    var bmp by remember(url) { mutableStateOf<Bitmap?>(null) }
    var boxes by remember(url) { mutableStateOf<List<TextBox>>(emptyList()) }

    LaunchedEffect(url) {
        val req = ImageRequest.Builder(ctx).data(url).allowHardware(false).size(Size.ORIGINAL).build()
        bmp = (ctx.imageLoader.execute(req) as? SuccessResult)?.drawable?.toBitmap()
    }
    LaunchedEffect(bmp, translate, src, dst) {
        val b = bmp
        boxes = if (translate && b != null) {
            runCatching { PageTranslator.translate(url, b, src, dst) }.getOrDefault(emptyList())
        } else emptyList()
    }

    val b = bmp
    if (b == null) {
        Box(Modifier.fillMaxWidth().height(300.dp), Alignment.Center) { CircularProgressIndicator() }
        return
    }
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val scale = constraints.maxWidth.toFloat() / b.width
        val d = LocalDensity.current
        Image(b.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
        boxes.forEach { t ->
            val w = t.rect.width() * scale
            val h = t.rect.height() * scale
            val fsPx = (sqrt(w * h / maxOf(t.text.length, 1)) * 0.85f).coerceIn(18f, 60f)
            with(d) {
                Box(
                    Modifier
                        .offset((t.rect.left * scale).toDp(), (t.rect.top * scale).toDp())
                        .size(w.toDp(), h.toDp())
                        .background(Color.White.copy(alpha = 0.93f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        t.text, color = Color.Black, textAlign = TextAlign.Center,
                        fontSize = fsPx.toSp(), lineHeight = fsPx.toSp() * 1.1f,
                        overflow = TextOverflow.Clip,
                    )
                }
            }
        }
    }
}
