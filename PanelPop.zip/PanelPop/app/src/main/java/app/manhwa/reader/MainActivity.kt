package app.manhwa.reader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import app.manhwa.reader.ui.App
import app.manhwa.reader.ui.AppViewModel

private val PanelPopColors = darkColorScheme(
    primary = Color(0xFFFF6FA3),
    onPrimary = Color.Black,
    secondary = Color(0xFFFFD23F),
    onSecondary = Color.Black,
    tertiary = Color(0xFFB28CFF),
    background = Color(0xFF0E0B16),
    onBackground = Color(0xFFEDE7F6),
    surface = Color(0xFF151020),
    onSurface = Color(0xFFEDE7F6),
    surfaceVariant = Color(0xFF241B35),
    onSurfaceVariant = Color(0xFFCFC3E6),
    secondaryContainer = Color(0xFF3A1F5E),
    onSecondaryContainer = Color(0xFFF1E6FF),
)

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = PanelPopColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App(vm) }
            }
        }
    }
}
