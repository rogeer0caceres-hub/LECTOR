package app.manhwa.reader

import android.app.Application
import app.manhwa.reader.data.UA
import coil.ImageLoader
import coil.ImageLoaderFactory
import okhttp3.OkHttpClient

/** Coil con Referer automático (muchas webs bloquean el hotlink). */
class ManhwaApp : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = ImageLoader.Builder(this)
        .okHttpClient {
            OkHttpClient.Builder().addInterceptor { chain ->
                val u = chain.request().url
                chain.proceed(
                    chain.request().newBuilder()
                        .header("Referer", "${u.scheme}://${u.host}/")
                        .header("User-Agent", UA)
                        .build()
                )
            }.build()
        }
        .crossfade(true)
        .build()
}
