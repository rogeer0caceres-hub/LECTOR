package app.manhwa.reader.data

import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URI

/** Dada la URL de una web, intenta generar una SourceDef automáticamente. */
object AutoDetector {
    data class Result(val source: SourceDef, val kind: String, val sample: List<Manhwa>)

    private const val IMG = "img@data-src||img@data-lazy-src||img@src"
    private const val CHAPTER_RX =
        """a:matches((?i)(cap[ií]tulo|chapter|chap\.?|cap\.?|ch\.?|episod[eio]?|ep\.?|화|話|话)\s*\d+)"""

    suspend fun detect(raw: String): Result {
        val url = if (raw.trim().startsWith("http")) raw.trim() else "https://${raw.trim()}"
        val html = Http.get(url)
        val doc = Jsoup.parse(html, url)
        val uri = URI(url)
        val base = "${uri.scheme}://${uri.host}"
        val id = uri.host.removePrefix("www.")
        val name = doc.title().ifBlank { id }.take(40)

        val (kind, src) = when {
            html.contains("wp-manga") || html.contains("madara", ignoreCase = true) -> "Madara" to madara(id, name, base)
            doc.select(".bsx, .listupd").isNotEmpty() -> "MangaStream" to mangaStream(id, name, base)
            else -> "Heurística" to heuristic(doc, id, name, base, url)
        }
        val sample = SourceEngine.catalog(src, 1)
        if (sample.isEmpty()) {
            error("Se detectó «$kind» pero no se encontraron series. Prueba con la URL del listado de series.")
        }
        return Result(src, kind, sample)
    }

    private fun madara(id: String, name: String, base: String) = SourceDef(
        id, name, base,
        CatalogSel("/manga/page/{page}/", ".page-item-detail", ".post-title a", IMG, ".post-title a@href"),
        ChapterSel(".wp-manga-chapter", "a", "a@href", ".chapter-release-date"),
        PageSel(".reading-content img@data-src||.reading-content img@src"),
        kind = "madara",
    )

    private fun mangaStream(id: String, name: String, base: String) = SourceDef(
        id, name, base,
        CatalogSel("/manga/?page={page}", ".bsx", "a@title", "img@data-src||img@src", "a@href"),
        ChapterSel("#chapterlist li", ".chapternum", "a@href", ".chapterdate"),
        PageSel("#readerarea img@data-src||#readerarea img@src"),
        kind = "mangastream",
    )

    private fun esc(s: String) = s.replace(Regex("([^a-zA-Z0-9_-])"), "\\\\$1")

    private fun sig(e: Element): String =
        esc(e.tagName()) + e.classNames().filter { it.isNotBlank() }.joinToString("") { "." + esc(it) }

    private fun path(url: String): String {
        val u = URI(url)
        val p = u.rawPath.orEmpty().ifEmpty { "/" }
        return if (u.rawQuery != null) "$p?${u.rawQuery}" else p
    }

    private fun heuristic(doc: Document, id: String, name: String, base: String, url: String): SourceDef {
        val groups = doc.select("a:has(img)").toList()
            .filter { it.parent() != null }
            .groupBy { sig(it.parent()!!) }
        val best = groups.maxByOrNull { it.value.size }?.takeIf { it.value.size >= 4 }
            ?: error("No se detectó un listado de series en esa página.")
        val sharedParent = best.value.map { it.parent() }.distinct().size == 1
        val catalog = if (sharedParent) {
            CatalogSel(path(url), "${best.key} > a:has(img)", "img@alt||@title", IMG, "@href")
        } else {
            CatalogSel(path(url), "${best.key}:has(a):has(img)", "a@title||img@alt||h3||h2||h4||.title", IMG, "a@href")
        }
        return SourceDef(
            id, name, base, catalog,
            ChapterSel(CHAPTER_RX, "@text", "@href"),
            PageSel("img@data-src||img@data-lazy-src||img@src"),
        )
    }
}
