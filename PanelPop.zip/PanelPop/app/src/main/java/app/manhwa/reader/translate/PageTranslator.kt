package app.manhwa.reader.translate

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await

data class TextBox(val rect: Rect, val text: String)

/** OCR + traducción en el dispositivo. Idiomas: ko, ja, zh, en, es, pt, fr... */
object PageTranslator {
    private val lock = Mutex()
    private val translators = mutableMapOf<String, Translator>()
    private val cache = mutableMapOf<String, List<TextBox>>()
    private const val SLICE = 1600

    private fun recognizer(lang: String): TextRecognizer = when (lang) {
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun translate(key: String, bmp: Bitmap, src: String, dst: String): List<TextBox> =
        lock.withLock {
            val ck = "$src>$dst>$key"
            cache[ck]?.let { return@withLock it }

            val tr = translators.getOrPut("$src>$dst") {
                Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build()
                )
            }
            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            val rec = recognizer(src)

            val out = mutableListOf<TextBox>()
            var y = 0
            while (y < bmp.height) {
                val h = minOf(SLICE, bmp.height - y)
                val slice = Bitmap.createBitmap(bmp, 0, y, bmp.width, h)
                val res = rec.process(InputImage.fromBitmap(slice, 0)).await()
                for (b in res.textBlocks) {
                    val r = b.boundingBox ?: continue
                    val t = b.text.replace("\n", " ").trim()
                    if (t.length < 2) continue
                    out += TextBox(Rect(r.left, r.top + y, r.right, r.bottom + y), tr.translate(t).await())
                }
                y += h
            }
            cache[ck] = out
            out
        }
}
