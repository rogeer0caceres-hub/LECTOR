package app.manhwa.reader.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URL
import java.util.concurrent.TimeUnit

const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

object Http {
    private val client = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()

    suspend fun get(url: String, referer: String? = null): String =
        call(Request.Builder().url(url), referer)

    suspend fun post(url: String, referer: String? = null): String =
        call(Request.Builder().url(url).post("".toRequestBody()), referer)

    private suspend fun call(b: Request.Builder, referer: String?): String = withContext(Dispatchers.IO) {
        b.header("User-Agent", UA)
        if (referer != null) b.header("Referer", referer)
        client.newCall(b.build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            r.body?.string().orEmpty()
        }
    }
}

private fun resolve(e: Element, attr: String): String {
    val raw = e.attr(attr).trim()
    if (raw.isEmpty()) return ""
    return runCatching { URL(URL(e.baseUri()), raw).toString() }.getOrDefault(raw)
}

private fun pickOne(el: Element, sel: String): String {
    val parts = sel.split("@", limit = 2)
    val css = parts[0].trim()
    val attr = parts.getOrElse(1) { "" }.trim()
    val target = if (css.isEmpty()) el else (el.selectFirst(css) ?: return "")
    return when (attr) {
        "", "text" -> target.text().trim()
        "html" -> target.html().trim()
        else -> resolve(target, attr)
    }
}

/** Devuelve el primer valor no vacío entre las alternativas separadas por "||". */
fun Element.pick(sel: String): String {
    if (sel.isBlank()) return ""
    for (alt in sel.split("||")) {
        val v = pickOne(this, alt)
        if (v.isNotEmpty()) return v
    }
    return ""
}

fun Document.pickAll(sel: String): List<String> {
    for (alt in sel.split("||")) {
        val parts = alt.split("@", limit = 2)
        val css = parts[0].trim()
        val attr = parts.getOrElse(1) { "src" }.trim().ifEmpty { "src" }
        val urls = select(css).map { resolve(it, attr) }
            .filter { it.isNotEmpty() && !it.startsWith("data:") && !it.endsWith(".svg") && !it.endsWith(".gif") }
        if (urls.isNotEmpty()) return urls
    }
    return emptyList()
}

object SourceEngine {
    fun absolute(base: String, path: String): String =
        if (path.startsWith("http")) path else base.trimEnd('/') + "/" + path.trimStart('/')

    suspend fun catalog(s: SourceDef, page: Int): List<Manhwa> {
        val url = absolute(s.baseUrl, s.catalog.url.replace("{page}", page.toString()))
        val doc = Jsoup.parse(Http.get(url, s.baseUrl), url)
        return doc.select(s.catalog.item).mapNotNull { el ->
            val link = el.pick(s.catalog.link)
            val title = el.pick(s.catalog.title)
            if (link.isEmpty() || title.isEmpty()) null else Manhwa(title, el.pick(s.catalog.cover), link, s.id)
        }.distinctBy { it.url }
    }

    /** Siempre devuelve los capítulos del más nuevo al más antiguo. */
    suspend fun chapters(s: SourceDef, manhwaUrl: String): List<Chapter> {
        var doc = Jsoup.parse(Http.get(manhwaUrl, s.baseUrl), manhwaUrl)
        var els = doc.select(s.chapters.item)
        if (els.isEmpty() && s.kind == "madara") {
            val ajax = manhwaUrl.trimEnd('/') + "/ajax/chapters/"
            doc = Jsoup.parse(Http.post(ajax, manhwaUrl), manhwaUrl)
            els = doc.select(s.chapters.item)
        }
        val list = els.mapNotNull { el ->
            val link = el.pick(s.chapters.link)
            if (link.isEmpty()) null
            else Chapter(el.pick(s.chapters.title).ifEmpty { "Capítulo" }, link, el.pick(s.chapters.date))
        }.distinctBy { it.url }
        return if (s.chapters.reverse) list.reversed() else list
    }

    suspend fun pages(s: SourceDef, chapterUrl: String): List<String> {
        val doc = Jsoup.parse(Http.get(chapterUrl, s.baseUrl), chapterUrl)
        return doc.pickAll(s.pages.images)
    }
}
