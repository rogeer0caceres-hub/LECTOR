# Panel Pop 💥

Lector y traductor de manhwas para Android. Kotlin + Jetpack Compose.

## Secciones
- **Biblioteca**: portadas con insignia de capítulos sin leer, pestañas *Todos / Sin leer* y búsqueda.
- **Novedades**: busca capítulos nuevos de tu biblioteca.
- **Historial**: lo último que leíste.
- **Explorar**: catálogo de cada fuente.
- **Más**: traducción ON/OFF, idioma destino, fuentes y repositorios.

## Fuentes
- Cada web se describe con un JSON de selectores CSS (`repo-ejemplo.json`). Sintaxis: `css@atributo`;
  sin atributo = texto; `a||b` = alternativas.
- Un repositorio es una URL que devuelve `{ "name": "...", "sources": [ ... ] }`.
- **Añadir web**: pega la URL de un listado; detecta Madara, MangaStream o usa una heurística, con vista previa.

## Traducción
OCR (ko/ja/zh) + traducción en el dispositivo con ML Kit. Los modelos se descargan la primera vez.

## Compilar
- **Android Studio**: abre la carpeta, sincroniza y ejecuta.
- **GitHub Actions**: sube `PanelPop.zip` y `.github/workflows/build.yml` al repositorio; descarga el APK en *Actions > Artifacts*.

## Logo
`icono-panelpop.svg` y `logo-panelpop.svg`. El icono de la app está en `app/src/main/res` (adaptive icon vectorial).

## Limitaciones
- Sitios con Cloudflare/JS obligatorio (HTTP 403) aún no soportados.
- El borrado del texto original es un relleno blanco, no inpainting real.
- Usa solo fuentes que tengas derecho a leer. La app no incluye ni aloja contenido.
