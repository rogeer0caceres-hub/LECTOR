# Manhwa Reader

Lector y traductor de manhwas para Android, estilo Mihon. Kotlin + Jetpack Compose.

## Abrir y ejecutar
1. Abre la carpeta con **Android Studio** (Koala o superior, JDK 17) y deja que sincronice Gradle.
2. Ejecuta en un emulador o móvil (Android 7.0+).

## Cómo funciona
- **Fuentes**: cada web se describe con un JSON de selectores CSS (`repo-ejemplo.json`).
  Sintaxis de selector: `css@atributo`. Sin atributo = texto. `a||b` = alternativas (usa la primera que dé resultado).
- **Repositorio**: una URL que devuelve `{ "name": "...", "sources": [ ... ] }`. Se añade en la pestaña *Fuentes*.
- **Añadir web**: pega la URL de un listado de series; la app detecta Madara, MangaStream o usa una heurística
  (grupos repetidos de enlaces con imagen) y muestra una vista previa antes de guardar.
- **Traducción**: ML Kit hace OCR (ko/ja/zh), traduce en el dispositivo y dibuja el texto sobre la burbuja.
  Los modelos de idioma se descargan la primera vez.
- `reverse = true` en `chapters` si la web lista los capítulos del más antiguo al más nuevo.

## Limitaciones conocidas
- Sitios con Cloudflare/JS obligatorio (HTTP 403) aún no están soportados (falta fallback con WebView).
- El borrado del texto original es un relleno blanco; no es inpainting real.
- Usa solo fuentes que tengas derecho a leer. La app no incluye ni aloja contenido.

## Compilar el APK con GitHub Actions
1. Sube esta carpeta a un repositorio de GitHub (rama `main`).
2. Ve a la pestaña **Actions > Build APK** (se ejecuta solo con cada push, o pulsa **Run workflow**).
3. Al terminar, abre la ejecución y descarga **ManhwaReader-apk** en la sección *Artifacts*.
4. Descomprime y pasa `app-debug.apk` al móvil para instalarlo.
