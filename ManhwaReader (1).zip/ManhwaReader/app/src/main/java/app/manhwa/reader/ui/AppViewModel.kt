package app.manhwa.reader.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.manhwa.reader.data.*
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString

sealed interface Screen {
    data object Library : Screen
    data object Browse : Screen
    data object Sources : Screen
    data class Detail(val m: Manhwa) : Screen
    data class Reader(val m: Manhwa, val index: Int) : Screen
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var sources by mutableStateOf(store.sources)
    var library by mutableStateOf(store.library)
    var read by mutableStateOf(store.read)
    var targetLang by mutableStateOf(store.targetLang)
    var translateOn by mutableStateOf(store.translateOn)
    var message by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)

    // ---- Navegación ----
    var screen: Screen by mutableStateOf(Screen.Library)
    val stack = mutableStateListOf<Screen>()
    fun go(s: Screen) { stack.add(screen); screen = s }
    fun replace(s: Screen) { screen = s }
    fun back() { if (stack.isNotEmpty()) screen = stack.removeAt(stack.lastIndex) }
    fun tab(s: Screen) { stack.clear(); error = null; screen = s }

    fun sourceOf(id: String): SourceDef? = sources.firstOrNull { it.id == id }

    // ---- Explorar ----
    var current by mutableStateOf<SourceDef?>(null)
    var items by mutableStateOf<List<Manhwa>>(emptyList())
    var loading by mutableStateOf(false)
    private var page = 1
    private var end = false

    fun selectSource(s: SourceDef) {
        current = s; items = emptyList(); page = 1; end = false; loading = false
        loadMore()
    }

    fun loadMore() {
        val s = current ?: return
        if (loading || end) return
        loading = true; error = null
        viewModelScope.launch {
            runCatching { SourceEngine.catalog(s, page) }
                .onSuccess { r ->
                    if (current?.id == s.id) {
                        val fresh = r.filter { n -> items.none { it.url == n.url } }
                        if (fresh.isEmpty()) end = true else { items = items + fresh; page++ }
                    }
                }
                .onFailure { error = it.message ?: "Error de red" }
            loading = false
        }
    }

    // ---- Detalle ----
    var chapters by mutableStateOf<List<Chapter>>(emptyList())
    var chLoading by mutableStateOf(false)

    fun openDetail(m: Manhwa) {
        go(Screen.Detail(m))
        chapters = emptyList(); error = null
        val s = sourceOf(m.sourceId)
        if (s == null) { error = "La fuente de esta serie ya no está instalada"; return }
        chLoading = true
        viewModelScope.launch {
            runCatching { SourceEngine.chapters(s, m.url) }
                .onSuccess { chapters = it }
                .onFailure { error = it.message ?: "Error de red" }
            chLoading = false
        }
    }

    fun toggleLibrary(m: Manhwa) {
        library = if (library.any { it.url == m.url }) library.filter { it.url != m.url } else library + m
        store.library = library
    }

    // ---- Lector ----
    var pages by mutableStateOf<List<String>>(emptyList())
    var pagesLoading by mutableStateOf(false)

    fun loadPages(m: Manhwa, ch: Chapter) {
        val s = sourceOf(m.sourceId) ?: return
        pages = emptyList(); pagesLoading = true; error = null
        viewModelScope.launch {
            runCatching { SourceEngine.pages(s, ch.url) }
                .onSuccess {
                    pages = it
                    read = read + ch.url; store.read = read
                    if (it.isEmpty()) error = "No se encontraron imágenes en este capítulo"
                }
                .onFailure { error = it.message ?: "Error de red" }
            pagesLoading = false
        }
    }

    fun setTarget(l: String) { targetLang = l; store.targetLang = l }
    fun toggleTranslate() { translateOn = !translateOn; store.translateOn = translateOn }

    // ---- Fuentes ----
    var busy by mutableStateOf(false)
    var detected by mutableStateOf<AutoDetector.Result?>(null)

    private fun merge(n: List<SourceDef>) {
        sources = sources.filter { o -> n.none { it.id == o.id } } + n
        store.sources = sources
    }

    fun addRepo(url: String) {
        busy = true
        viewModelScope.launch {
            runCatching { AppJson.decodeFromString<RepoIndex>(Http.get(url.trim())) }
                .onSuccess { merge(it.sources); message = "Repositorio añadido: ${it.sources.size} fuentes" }
                .onFailure { message = "No se pudo leer el repositorio: ${it.message}" }
            busy = false
        }
    }

    fun detect(url: String) {
        busy = true; detected = null
        viewModelScope.launch {
            runCatching { AutoDetector.detect(url) }
                .onSuccess { detected = it }
                .onFailure { message = it.message ?: "No se pudo detectar la web" }
            busy = false
        }
    }

    fun saveDetected() {
        detected?.let { merge(listOf(it.source)); message = "Fuente guardada"; detected = null }
    }

    fun removeSource(s: SourceDef) {
        sources = sources.filter { it.id != s.id }
        store.sources = sources
        if (current?.id == s.id) { current = null; items = emptyList() }
    }
}
