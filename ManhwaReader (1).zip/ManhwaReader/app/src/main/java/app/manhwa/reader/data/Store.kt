package app.manhwa.reader.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString

/** Persistencia simple (SharedPreferences + JSON). */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("manhwa", Context.MODE_PRIVATE)

    private inline fun <reified T> load(k: String, d: T): T =
        sp.getString(k, null)?.let { runCatching { AppJson.decodeFromString<T>(it) }.getOrNull() } ?: d

    private inline fun <reified T> save(k: String, v: T) {
        sp.edit().putString(k, AppJson.encodeToString(v)).apply()
    }

    var sources: List<SourceDef>
        get() = load("sources", emptyList())
        set(v) = save("sources", v)

    var library: List<Manhwa>
        get() = load("library", emptyList())
        set(v) = save("library", v)

    var read: Set<String>
        get() = load("read", emptySet())
        set(v) = save("read", v)

    var targetLang: String
        get() = load("target", "es")
        set(v) = save("target", v)

    var translateOn: Boolean
        get() = load("translate", false)
        set(v) = save("translate", v)
}
