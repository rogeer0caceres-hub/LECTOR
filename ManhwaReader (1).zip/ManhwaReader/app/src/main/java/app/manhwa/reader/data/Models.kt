package app.manhwa.reader.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

val AppJson = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
    isLenient = true
}

/** Selector: "css@atributo" (sin atributo = texto). "a||b" = alternativas. */
@Serializable
data class CatalogSel(val url: String, val item: String, val title: String, val cover: String, val link: String)

/** reverse = true si la web lista los capítulos del más antiguo al más nuevo. */
@Serializable
data class ChapterSel(val item: String, val title: String, val link: String, val date: String = "", val reverse: Boolean = false)

@Serializable
data class PageSel(val images: String)

@Serializable
data class SourceDef(
    val id: String,
    val name: String,
    val baseUrl: String,
    val catalog: CatalogSel,
    val chapters: ChapterSel,
    val pages: PageSel,
    val lang: String = "ko",
    val kind: String = "generic",
)

@Serializable
data class RepoIndex(val name: String = "", val sources: List<SourceDef> = emptyList())

@Serializable
data class Manhwa(val title: String, val cover: String, val url: String, val sourceId: String)

@Serializable
data class Chapter(val title: String, val url: String, val date: String = "")
